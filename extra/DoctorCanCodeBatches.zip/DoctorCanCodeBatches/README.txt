Pre-requirement
---------------
1. Install Node.js from http://nodejs.org/
2. Download Apache Ant (.zip archive) from http://ant.apache.org/bindownload.cgi
3. Unzip Apache Ant .zip archive to C:\
4. Locate the path of the Apache Ant bin folder

Installation
------------
Place the two folder at User Documents directory.

Usage
-----
1. Installation.bat 
	- enter Apache Ant's bin path in console
	- auto installation of npm, cordova and ionic
	- start HelloWorld project automatically
	
2. StartHelloDoctorProject.bat
	- start HelloWorld project automatically